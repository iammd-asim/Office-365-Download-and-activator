# Office 365 Activator
This is my Office 365 Activator Program. You can activate your Office 365 for Free.</br>
License is Professional Plus 2021.

## ⚙️Usage
* First you need to run this program as an administrator.
* You must write the number that is written in front of the specific option and click enter.  

## 🖼️This is the interface of my Activator
![Activator](https://github.com/muki01/Office_365-Activator/assets/75759731/234ec032-b1be-4dd9-93ef-4c699e03736f)
